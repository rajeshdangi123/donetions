from django.shortcuts import render
from django.http import HttpResponse

def base(request):
    return render( request,"app1/base.html")
def aboutus(request):
    return render(request ,"app1/aboutus.html")
def Donetion(request):
    return render(request , "app1/donetion.html")

# Create your views here.
