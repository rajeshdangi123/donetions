""
from django.contrib import admin
from django.urls import path

from app1 import views

urlpatterns = [
    path('',views.base,name="base"),
    path('aboutus',views.aboutus,name="aboutus"),
    path("Donetion",views.Donetion,name="Donetion"),
  
]
